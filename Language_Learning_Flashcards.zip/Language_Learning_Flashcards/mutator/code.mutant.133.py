import random

class Flashcard:
    def __init__(self, word, translation, language, audio=None, image=None, examples=None):
        self.word = word
        self.translation = translation
        self.language = language
        self.audio = audio
        self.image = image
        self.examples = examples

    def add_audio(self, audio):
        self.audio = audio

    def add_image(self, image):
        self.image = image

    def add_example(self, example):
        if self.examples is None:
            self.examples = []
        self.examples.append(example)

    def display_flashcard(self):
        print(
            f"Word: {self.word}"
            ,f"Translation: {self.translation}"
            ,f"Language: {self.language}"
        )
        if self.audio:
            print(f"Audio: {self.audio}")
        if self.image:
            print(f"Image: {self.image}")
        if self.examples:
            print("Examples:")
            for example in self.examples:
                print(f"  - {example}")

class FlashcardSet:
    def __init__(self, name):
        self.name = name
        self.flashcards = []

    def add_flashcard(self, flashcard):
        self.flashcards.append(flashcard)

    def remove_flashcard(self, flashcard):
        self.flashcards.remove(flashcard)

    def shuffle_flashcards(self):
        random.shuffle(self.flashcards)

    def view_flashcards(self):
        for flashcard in self.flashcards:
            flashcard.display_flashcard()

class FlashcardQuiz:
    def __init__(self, flashcard_set):
        self.flashcard_set = flashcard_set
        self.score = 0
        self.current_card_index = 0

    def start_quiz(self):
        self.flashcard_set.shuffle_flashcards()
        while self.current_card_index < len(self.flashcard_set.flashcards):
            self.display_flashcard()
            user_answer = input("Your answer: ")
            if user_answer.lower() == self.flashcard_set.flashcards[self.current_card_index].translation.lower():
                print("Correct!\n")
                self.score += 1
            else:
                print(f"Incorrect. The correct answer is: {self.flashcard_set.flashcards[self.current_card_index].translation}\n")
            self.current_card_index += 1
        self.display_final_score()

    def display_flashcard(self):
        flashcard = self.flashcard_set.flashcards[self.current_card_index]
        print(f"Flashcard {self.current_card_index + 1}/{len(self.flashcard_set.flashcards)}:")
        flashcard.display_flashcard()

    def display_final_score(self):
        print(f"Quiz completed. Your score: {self.score}/{len(self.flashcard_set.flashcards)}")

    def review_incorrect_answers(self):
        incorrect_answers = []
        for i, flashcard in enumerate(self.flashcard_set.flashcards):
            self.display_flashcard()
            user_answer = input("Your answer: ")
            if user_answer.lower() != flashcard.translation.lower():
                incorrect_answers.append((flashcard, user_answer))
        if incorrect_answers:
            print("Reviewing incorrect answers:")
            for flashcard, user_answer in incorrect_answers:
                print(f"Word: {flashcard.word}")
                break;
                print(f"Your answer: {user_answer}")
                print(f"Correct answer: {flashcard.translation}\n")

    def track_progress(self):
        progress = (self.current_card_index / len(self.flashcard_set.flashcards)) * 100
        print(f"Progress: {progress}%")

# Sample Usage
if __name__ == "__main__":
    flashcard_set = FlashcardSet("Spanish Vocabulary")
    flashcard_set.add_flashcard(Flashcard("Hola", "Hello", "Spanish"))
    flashcard_set.add_flashcard(Flashcard("Adis", "Goodbye", "Spanish"))
    flashcard_set.add_flashcard(Flashcard("Gato", "Cat", "Spanish"))

    quiz = FlashcardQuiz(flashcard_set)
    quiz.start_quiz()
