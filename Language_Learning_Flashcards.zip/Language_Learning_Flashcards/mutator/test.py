import unittest
from unittest.mock import patch
import random
# Import the classes from your code
from code import Flashcard, FlashcardSet, FlashcardQuiz

class TestFlashcard(unittest.TestCase):
    def test_add_audio(self):
        flashcard = Flashcard("Hola", "Hello", "Spanish")
        flashcard.add_audio("audio.mp3")
        self.assertEqual(flashcard.audio, "audio.mp3")

    def test_add_image(self):
        flashcard = Flashcard("Hola", "Hello", "Spanish")
        flashcard.add_image("image.jpg")
        self.assertEqual(flashcard.image, "image.jpg")

    def test_add_example(self):
        flashcard = Flashcard("Hola", "Hello", "Spanish")
        flashcard.add_example("Example sentence.")
        self.assertEqual(flashcard.examples, ["Example sentence."])

class TestFlashcardSet(unittest.TestCase):
    def setUp(self):
        self.flashcard_set = FlashcardSet("Spanish Vocabulary")
        self.flashcard1 = Flashcard("Hola", "Hello", "Spanish")
        self.flashcard2 = Flashcard("Adiós", "Goodbye", "Spanish")

    def test_add_flashcard(self):
        self.flashcard_set.add_flashcard(self.flashcard1)
        self.assertEqual(len(self.flashcard_set.flashcards), 1)

    def test_remove_flashcard(self):
        self.flashcard_set.add_flashcard(self.flashcard1)
        self.flashcard_set.remove_flashcard(self.flashcard1)
        self.assertEqual(len(self.flashcard_set.flashcards), 0)

    def test_shuffle_flashcards(self):
        self.flashcard_set.add_flashcard(self.flashcard1)
        self.flashcard_set.add_flashcard(self.flashcard2)
        random.seed(123)  # Set seed for reproducibility
        self.flashcard_set.shuffle_flashcards()
        self.assertNotEqual(self.flashcard_set.flashcards, [self.flashcard1, self.flashcard2])

    @patch("builtins.print")
    def test_view_flashcards(self, mock_print):
        self.flashcard_set.add_flashcard(self.flashcard1)
        self.flashcard_set.view_flashcards()
        mock_print.assert_called_with(
            f"Word: {self.flashcard1.word}",
            f"Translation: {self.flashcard1.translation}",
            f"Language: {self.flashcard1.language}"
        )

class TestFlashcardQuiz(unittest.TestCase):
    def setUp(self):
        self.flashcard_set = FlashcardSet("Spanish Vocabulary")
        self.flashcard1 = Flashcard("Hola", "Hello", "Spanish")
        self.flashcard2 = Flashcard("Adiós", "Goodbye", "Spanish")
        self.flashcard_set.add_flashcard(self.flashcard1)
        self.flashcard_set.add_flashcard(self.flashcard2)
        self.quiz = FlashcardQuiz(self.flashcard_set)

    @patch("builtins.input", side_effect=["Hello", "Goodbye"])
    @patch("builtins.print")
    def test_start_quiz(self, mock_print, mock_input):
        self.quiz.start_quiz()
        self.assertEqual(self.quiz.score, 2)
        mock_print.assert_any_call("Correct!\n")
        mock_print.assert_any_call("Quiz completed. Your score: 2/2")

    @patch("builtins.input", side_effect=["Hello", "Wrong"])
    @patch("builtins.print")
    def test_review_incorrect_answers(self, mock_print, mock_input):
        self.quiz.review_incorrect_answers()
        mock_print.assert_any_call("Reviewing incorrect answers:")
        mock_print.assert_any_call(f"Word: {self.flashcard2.word}")
        mock_print.assert_any_call(f"Your answer: Wrong")
        mock_print.assert_any_call(f"Correct answer: {self.flashcard2.translation}\n")

    @patch("builtins.print")
    def test_track_progress(self, mock_print):
        self.quiz.current_card_index = 1
        self.quiz.track_progress()
        mock_print.assert_called_with("Progress: 50.0%")

if __name__ == "__main__":
    unittest.main()
